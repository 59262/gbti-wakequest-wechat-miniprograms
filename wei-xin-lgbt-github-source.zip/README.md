# 微信小程序集合：GBTI 与 WakeQuest

这是一个原生微信小程序项目集合，当前包含两个相互独立的实验性小程序：

- **GBTI「人类异常分类报告」**：18 道本地问答题，根据选项分数生成娱乐性质的“精神物种”结果，并支持生成结果卡片保存到相册。
- **WakeQuest「醒醒任务」**：闹钟与动作任务的 MVP。当前版本提供响铃、震动、相机页面和手动完成次数；动作识别模型尚未接入当前工作树。

本仓库不包含后端、云函数、数据库或远程 API。两个小程序的主要计算均在设备端完成。

## 功能边界

GBTI 结果只用于娱乐，不构成人格、性取向、性别认同、心理或医学判断。WakeQuest 当前不能可靠地验证深蹲动作，也没有实现真正的系统级定时唤醒；“预览响铃流程”是可用的演示路径。

## 项目结构

```text
.
├── app.json / app.js / app.wxss       # GBTI 小程序入口
├── pages/                             # GBTI 页面
├── components/                        # GBTI 可复用组件
├── data/                              # 题目、评分规则和结果文案
├── utils/                             # 结果卡片绘制与计算
├── assets/                            # GBTI 图片和音频资源
├── GBTI_全量人格卡片_设计包_v1/        # 设计参考包和预览素材
└── wakequest-miniprogram/             # 独立的 WakeQuest 小程序
    ├── pages/
    ├── assets/
    ├── package.json / pnpm-lock.yaml
    └── movenet_lightning_int8.tflite  # 预留模型资源，当前代码未加载
```

`wakequest-miniprogram` 内原有一个嵌套 Git 元数据目录和本地修改记录。发布外层仓库时应只发布文件内容，并按 [SECURITY_AUDIT.md](SECURITY_AUDIT.md) 处理嵌套仓库历史。

## 环境要求

- 微信开发者工具（建议使用当前稳定版）。
- Node.js 与 pnpm：WakeQuest 依赖 TensorFlow.js 3.5.0，建议使用 Node.js 18 或 20，并使用 pnpm 9 系列以匹配现有 lockfile。
- 真机测试时需要按需授权相机和保存图片到相册的权限。

当前环境使用 Node.js `v24.14.0`，已完成语法检查，但未以该版本完成微信开发者工具真机验证。

## 安装与运行

### GBTI

1. 在微信开发者工具中导入仓库根目录。
2. 将 `project.config.json` 中的 `appid` 替换为你自己的小程序 AppID；没有 AppID 时使用测试号或开发者工具提供的本地方案。
3. 编译并在模拟器或真机中依次测试首页、18 道题、结果页和保存结果卡片流程。

### WakeQuest

1. 在微信开发者工具中单独导入 `wakequest-miniprogram/`。
2. 在该目录安装依赖：

   ```powershell
   corepack enable
   pnpm install --frozen-lockfile
   ```

3. 在开发者工具中执行“工具 → 构建 npm”，生成被 `.gitignore` 忽略的 `miniprogram_npm/`。
4. 将 `wakequest-miniprogram/project.config.json` 中的 `appid` 替换为你自己的 AppID。
5. 从首页进入“预览响铃流程”，再进入任务页。当前计数需要点击“我已完成一次深蹲”。

## 配置方法

项目没有环境变量，也没有服务端配置，因此不创建 `.env.example`。`project.private.config.json` 是微信开发者工具的本地设置文件，发布时不应提交；根目录 `.gitignore` 已覆盖两个小程序的该文件。

AppID 是微信项目标识，不是 API 密钥，但会把代码与某个微信开发者项目关联。公开仓库应使用作者确认过的公开测试 AppID 或占位值。

## 数据与隐私

- GBTI 的题目答案、评分和结果只在本地内存中处理，不调用网络接口，也不写入本地存储。
- GBTI 的“保存结果卡片”会请求相册写入权限；用户应明确知道图片会写入设备相册。
- WakeQuest 的动作页会打开前置相机，但当前代码没有启动帧监听或上传相机帧；它只是手动计数 MVP。若重新启用模型推理，必须重新审查相机数据处理、模型下载地址和微信隐私申报。
- 仓库不应加入真实日记、健康记录、账号信息、聊天记录或带个人文件路径的截图。

## 测试与检查

当前没有自动化测试脚本。发布前可在仓库根目录运行：

```powershell
$files = rg --files -g '*.js' -g '!**/node_modules/**' -g '!**/miniprogram_npm/**'
foreach ($file in $files) { node --check $file }
node -e "const q=require('./data/questions'); const c=require('./utils/calculator'); const a=q.map(()=> 'A'); const r=c.generateResult(c.calculateFromAnswers(q,a),q,a); if(!r.resultId) process.exit(1); console.log('calculator smoke test passed')"
```

然后在微信开发者工具中完成两个小程序的页面和权限手工测试。依赖审计可在 `wakequest-miniprogram/` 中运行 `pnpm audit`。

## 已知限制

- WakeQuest 的闹钟调度、后台保活和真正的动作识别尚未完成。
- WakeQuest 保留了 TensorFlow.js 依赖、模型文件和旧的生成包，但当前工作树没有加载它们；这些内容需要在后续版本中统一清理或重新接入。
- 资源（插画、音频、字体或模型）的作者和许可证尚未在仓库中逐项记录。
- 微信开发者工具和真机行为未在所有系统、机型和微信版本上验证。

## 贡献方式

请先阅读 [CONTRIBUTING.md](CONTRIBUTING.md)。提交代码时不要提交本地配置、依赖目录、真实用户数据或未确认授权的素材；涉及评分规则、隐私范围和模型接入的改动，应在 PR 中说明影响。

## 许可证

当前仓库**未声明许可证**。代码、图片、音频、模型和设计包的权利来源尚未完整确认，不能默认按 MIT 或其他许可证使用。请先阅读 [LICENSE_SELECTION.md](LICENSE_SELECTION.md)，由作者确认代码与各类资源的授权范围后再添加正式 `LICENSE` 文件。
