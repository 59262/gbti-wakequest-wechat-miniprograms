App({
  globalData: {
    appName: '人类异常分类报告',
    bgmEnabled: true,
    bgmReady: false,
    bgm: null
  },

  onLaunch() {
    this.initBgm()
  },

  onShow() {
    if (this.globalData.bgmEnabled) {
      this.playBgm()
    }
  },

  onHide() {
    this.pauseBgm()
  },

  initBgm() {
    if (this.globalData.bgm) return

    const bgm = wx.createInnerAudioContext()
    bgm.src = '/assets/audio/bgm-main.mp3'
    bgm.loop = true
    bgm.volume = 0.42
    bgm.obeyMuteSwitch = false

    bgm.onCanplay(() => {
      this.globalData.bgmReady = true
    })

    bgm.onError(() => {
      this.globalData.bgmReady = false
    })

    this.globalData.bgm = bgm
  },

  playBgm() {
    this.initBgm()
    const bgm = this.globalData.bgm
    if (!bgm || !this.globalData.bgmEnabled) return

    try {
      bgm.play()
    } catch (error) {
      // Some devices require the first play call to happen after a user tap.
    }
  },

  pauseBgm() {
    const bgm = this.globalData.bgm
    if (bgm) {
      bgm.pause()
    }
  },

  setBgmEnabled(enabled) {
    this.globalData.bgmEnabled = enabled
    if (enabled) {
      this.playBgm()
    } else {
      this.pauseBgm()
    }
  },

  toggleBgm() {
    this.setBgmEnabled(!this.globalData.bgmEnabled)
    return this.globalData.bgmEnabled
  }
})
