Page({
  start() { wx.navigateTo({ url: '/pages/motion/motion' }) }
})
