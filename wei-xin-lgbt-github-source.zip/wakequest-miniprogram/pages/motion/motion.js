const app = getApp()
const TARGET_REPS = 5

Page({
  data: {
    count: 0,
    target: TARGET_REPS,
    cameraError: false,
    holding: false,
    status: '测试模式：完成一次深蹲后，点击下方按钮记一次。'
  },

  onReady() {
    this.camera = wx.createCameraContext()
  },

  confirmRep() {
    if (this.data.count >= TARGET_REPS) return
    const count = this.data.count + 1
    this.setData({
      count,
      status: count === TARGET_REPS
        ? '任务完成，闹钟已解除。'
        : `已完成 ${count} 次，再完成 ${TARGET_REPS - count} 次。`
    })
    if (count === TARGET_REPS) setTimeout(() => this.complete(), 600)
  },

  cameraError() {
    this.setData({ cameraError: true, status: '相机未开启，请到微信设置中允许相机权限。' })
  },

  complete() {
    app.globalData.session.count = TARGET_REPS
    app.stopAlarm()
    wx.redirectTo({ url: '/pages/done/done' })
  },

  emergencyStart() {
    this.setData({ holding: true })
    this.hold = setTimeout(() => {
      app.stopAlarm()
      wx.reLaunch({ url: '/pages/home/home' })
    }, 3000)
  },

  emergencyEnd() {
    clearTimeout(this.hold)
    this.setData({ holding: false })
  },

  onUnload() {
    clearTimeout(this.hold)
  }
})
