const app = getApp()

Page({
  data: { time: '', preview: false },

  onLoad(query) {
    const d = new Date()
    this.setData({
      time: `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`,
      preview: query.preview === '1'
    })
  },

  onShow() {
    // The alarm continues through the briefing and motion pages.
    app.startAlarm()
  },

  awake() {
    wx.navigateTo({ url: '/pages/task/task' })
  }
})
